import AnimatedButton from "./animated-button";

export default AnimatedButton;
