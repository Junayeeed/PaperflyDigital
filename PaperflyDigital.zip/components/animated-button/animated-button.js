"use client";

import React from "react";
import styles from "./animated-button.module.css";
import gsap from "gsap";
import Magnetic from "../magnetic";

export default function AnimatedButton({
  anchor,
  children,
  backgroundColor = "var(--white)",
  ...attributes
}) {
  const circle = React.useRef(null);
  let timeline = React.useRef(null);

  let timeoutId = null;
  React.useEffect(() => {
    timeline.current = gsap.timeline({ paused: true });
    timeline.current
      .to(
        circle.current,
        { top: "-25%", width: "150%", duration: 0.4, ease: "power3.in" },
        "enter"
      )
      .to(
        circle.current,
        { top: "-150%", width: "125%", duration: 0.25 },
        "exit"
      );
  }, []);

  const manageMouseEnter = () => {
    if (timeoutId) clearTimeout(timeoutId);
    timeline.current.tweenFromTo("enter", "exit");
  };

  const manageMouseLeave = () => {
    timeoutId = setTimeout(() => {
      timeline.current.play();
    }, 300);
  };

  const handleScroll = () => {
    const posts = document.getElementById(anchor);
    posts.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <Magnetic>
      <div
        className={styles.button}
        onMouseEnter={() => {
          manageMouseEnter();
        }}
        onMouseLeave={() => {
          manageMouseLeave();
        }}
        onClick={handleScroll}
        {...attributes}
      >
        {children}
        <div
          ref={circle}
          style={{ backgroundColor }}
          className={styles.circle}
        ></div>
      </div>
    </Magnetic>
  );
}
