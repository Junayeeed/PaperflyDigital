import NewsPost from "./news-post";

export default NewsPost;
