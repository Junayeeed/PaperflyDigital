import Fact from "./fact";

export default Fact;
