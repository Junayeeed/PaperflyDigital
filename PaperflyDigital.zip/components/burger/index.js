import Burger from "./burger";

export default Burger;
