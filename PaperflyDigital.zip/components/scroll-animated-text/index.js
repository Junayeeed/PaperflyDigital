import ScrollAnimatedText from "./scroll-animated-text";

export default ScrollAnimatedText;
