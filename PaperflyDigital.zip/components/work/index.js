import Work from "./work";

export default Work;
