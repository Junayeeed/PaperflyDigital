import TextMarquee from "./text-marquee";

export default TextMarquee;
