import Service from "./service";

export default Service;
