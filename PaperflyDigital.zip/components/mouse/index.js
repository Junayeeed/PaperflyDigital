import Mouse from "./mouse";

export default Mouse;
