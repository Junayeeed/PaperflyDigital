import Magnetic from "./magnetic";

export default Magnetic;
