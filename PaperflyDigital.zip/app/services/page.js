import ServicesPage from "@/screens/services";

export default function Services() {
  return <ServicesPage />;
}
