import ContactPage from "@/screens/contact";

export default function Contact() {
  return <ContactPage />;
}
