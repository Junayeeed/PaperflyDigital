import NewsPage from "@/screens/news";

export default function News() {
  return <NewsPage />;
}
