import HomePage from "@/screens/home";
import React from "react";

export default function Home() {
  return <HomePage />;
}
