import ApproachPage from "@/screens/approach";

export default function Approach() {
  return <ApproachPage />;
}
