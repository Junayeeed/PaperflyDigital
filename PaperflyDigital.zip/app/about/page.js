import AboutPage from "@/screens/about";

export default function About() {
  return <AboutPage />;
}
