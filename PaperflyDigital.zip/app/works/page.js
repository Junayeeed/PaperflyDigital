import WorksPage from "@/screens/works";

export default function Works() {
  return <WorksPage />;
}
