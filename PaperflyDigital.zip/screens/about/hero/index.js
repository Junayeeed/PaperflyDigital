import Hero from "./hero";

export default Hero;
