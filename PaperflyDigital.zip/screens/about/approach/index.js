import Approach from "./approach";

export default Approach;
