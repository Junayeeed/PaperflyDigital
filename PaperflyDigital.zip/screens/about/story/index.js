import Story from "./story";

export default Story;
