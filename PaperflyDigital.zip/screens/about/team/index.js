import Team from "./team";

export default Team;
