import Video from "./video";

export default Video;
