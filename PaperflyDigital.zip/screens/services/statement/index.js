import Statement from "./statement";

export default Statement;
