import Facts from "./facts";

export default Facts;
