import News from "./news";

export default News;
