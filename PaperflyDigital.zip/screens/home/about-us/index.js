import AboutUs from "./about-us";

export default AboutUs;
