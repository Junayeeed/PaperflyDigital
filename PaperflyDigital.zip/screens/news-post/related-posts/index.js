import RelatedPosts from "./related-posts";

export default RelatedPosts;
