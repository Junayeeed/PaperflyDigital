import Slogan from "./slogan";

export default Slogan;
