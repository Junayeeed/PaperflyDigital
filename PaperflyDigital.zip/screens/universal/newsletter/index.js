import Newsletter from "./newsletter";

export default Newsletter;
