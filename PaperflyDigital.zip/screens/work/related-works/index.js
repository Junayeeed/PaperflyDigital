import RelatedWorks from "./related-works";

export default RelatedWorks;
